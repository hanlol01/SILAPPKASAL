import { Link } from "@tanstack/react-router";
import { FileText, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { PortalStatusBadge } from "@/components/portal/portal-status-badge";
import { formatDate } from "@/lib/format";
import { portalReportTypeLabel } from "@/lib/portal-labels";
import type { PortalReport } from "@/lib/portal-types";
import { useTranslation } from "react-i18next";

interface PortalReportCardProps {
  report: PortalReport;
}

/**
 * A single report card for the "My Reports" list.
 *
 * Shows only reporter-safe fields — no internal IDs, no workflow details.
 * Uses registration_number as the visible identifier and navigation key.
 */
export function PortalReportCard({ report }: PortalReportCardProps) {
  const { t, i18n } = useTranslation(["portal", "common"]);
  // safely extract string category if backend accidentally returns an object
  const categoryLabel =
    typeof report.category === "object" && report.category !== null
      ? (report.category as { name?: string }).name
      : report.category;

  return (
    <Card className="transition-colors hover:bg-muted/40">
      <CardContent className="flex items-center gap-4 p-4">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
          <FileText className="h-5 w-5" />
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-mono text-sm font-medium">
              {report.registration_number}
            </span>
            <PortalStatusBadge
              portalStatus={report.portal_status}
            />
            {report.report_type === "anonymous" && (
              <Badge variant="outline" className="gap-1 text-muted-foreground">
                <Lock className="h-3 w-3" />
                {t("portal:anonymousReport")}
              </Badge>
            )}
          </div>
          <div className="mt-1 flex flex-wrap gap-x-4 gap-y-0.5 text-xs text-muted-foreground">
            <span>{portalReportTypeLabel(report.report_type, i18n.language)}</span>
            {categoryLabel && <span>{categoryLabel}</span>}
            <span>{t("portal:submittedDate", { date: formatDate(report.submitted_at, i18n.language) })}</span>
          </div>
        </div>

        <Button
          variant="ghost"
          size="sm"
          className="shrink-0"
          asChild
        >
          <Link
            to="/portal/reports/$registrationNumber"
            params={{ registrationNumber: report.registration_number }}
          >
            {t("common:view")}
          </Link>
        </Button>
      </CardContent>
    </Card>
  );
}
